const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 3000;
const SCORE_FILE = path.join(__dirname, "highscore.json");

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));
// Serve three.js locally from node_modules - no CDN needed, works fully offline.
app.use("/vendor", express.static(path.join(__dirname, "node_modules", "three", "build")));

function readHighScore() {
  try {
    const raw = fs.readFileSync(SCORE_FILE, "utf-8");
    return JSON.parse(raw).highScore || 0;
  } catch (e) {
    return 0;
  }
}

function writeHighScore(score) {
  fs.writeFileSync(SCORE_FILE, JSON.stringify({ highScore: score }), "utf-8");
}

// Backend <-> Frontend connection lives here.
// The browser calls these two endpoints over plain HTTP - no external API, no key needed.
app.get("/api/highscore", (req, res) => {
  res.json({ highScore: readHighScore() });
});

app.post("/api/highscore", (req, res) => {
  const { score } = req.body;
  const current = readHighScore();
  if (typeof score === "number" && score > current) {
    writeHighScore(score);
    return res.json({ highScore: score, updated: true });
  }
  res.json({ highScore: current, updated: false });
});

app.listen(PORT, () => {
  console.log(`Cockroach Run is scuttling at http://localhost:${PORT}`);
});
