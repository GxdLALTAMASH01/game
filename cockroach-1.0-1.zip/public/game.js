// ===== Roach Chase — real 3D build (Three.js) =====
// Over-the-shoulder chase runner. Backend connection is just
// GET/POST /api/highscore - no external API, no key needed.

const viewport = document.getElementById("viewport");
const scoreEl = document.getElementById("score");
const bestEl = document.getElementById("best");
const gapFillEl = document.getElementById("gapFill");
const startScreen = document.getElementById("startScreen");
const gameOverScreen = document.getElementById("gameOverScreen");
const finalScoreEl = document.getElementById("finalScore");
const newBestEl = document.getElementById("newBest");
const startBtn = document.getElementById("startBtn");
const retryBtn = document.getElementById("retryBtn");

// ---------- three.js setup ----------
const scene = new THREE.Scene();
const FOG_COLOR = 0x120d0a;
scene.fog = new THREE.Fog(FOG_COLOR, 14, 55);
scene.background = new THREE.Color(FOG_COLOR);

const camera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.1, 200);
camera.position.set(0, 3.4, 6.2);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
viewport.appendChild(renderer.domElement);

window.addEventListener("resize", () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

// ---------- lights ----------
scene.add(new THREE.AmbientLight(0x453322, 0.75));
const bulb = new THREE.PointLight(0xffc98a, 1.6, 40, 2);
bulb.position.set(0, 6, -4);
scene.add(bulb);
const rim = new THREE.DirectionalLight(0x8899ff, 0.18);
rim.position.set(-5, 6, 4);
scene.add(rim);

// ---------- floor (scrolling texture, no geometry recycling needed) ----------
function makeFloorTexture() {
  const c = document.createElement("canvas");
  c.width = 256; c.height = 512;
  const g = c.getContext("2d");
  g.fillStyle = "#241b14";
  g.fillRect(0, 0, c.width, c.height);
  g.strokeStyle = "rgba(240,169,78,0.18)";
  g.lineWidth = 3;
  // lane dividers
  g.beginPath(); g.moveTo(c.width * 0.33, 0); g.lineTo(c.width * 0.33, c.height); g.stroke();
  g.beginPath(); g.moveTo(c.width * 0.66, 0); g.lineTo(c.width * 0.66, c.height); g.stroke();
  // tile seams
  g.strokeStyle = "rgba(0,0,0,0.35)";
  g.lineWidth = 2;
  for (let y = 0; y < c.height; y += 64) {
    g.beginPath(); g.moveTo(0, y); g.lineTo(c.width, y); g.stroke();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(1, 40);
  return tex;
}
const floorTex = makeFloorTexture();
const floor = new THREE.Mesh(
  new THREE.PlaneGeometry(9, 400),
  new THREE.MeshStandardMaterial({ map: floorTex, roughness: 0.95 })
);
floor.rotation.x = -Math.PI / 2;
floor.position.set(0, 0, -160);
scene.add(floor);

// side walls for a hallway feel
function makeWall(x) {
  const wall = new THREE.Mesh(
    new THREE.BoxGeometry(1, 8, 400),
    new THREE.MeshStandardMaterial({ color: 0x1a130e, roughness: 1 })
  );
  wall.position.set(x, 3, -160);
  scene.add(wall);
}
makeWall(-5.2);
makeWall(5.2);

// hanging lamps for depth cues, recycled like obstacles
const lamps = [];
for (let i = 0; i < 6; i++) {
  const lamp = new THREE.Mesh(
    new THREE.SphereGeometry(0.18, 8, 8),
    new THREE.MeshBasicMaterial({ color: 0xffdca0 })
  );
  lamp.position.set(0, 5.6, -i * 20 - 10);
  scene.add(lamp);
  lamps.push(lamp);
}

// ---------- helpers ----------
const lerp = (a, b, t) => a + (b - a) * t;
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

function shadowBlob(radius) {
  const m = new THREE.Mesh(
    new THREE.CircleGeometry(radius, 16),
    new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.4 })
  );
  m.rotation.x = -Math.PI / 2;
  m.position.y = 0.02;
  scene.add(m);
  return m;
}

// ---------- player ----------
const LANES = [-2.1, 0, 2.1];

function buildPlayer() {
  const group = new THREE.Group();
  const skin = new THREE.MeshStandardMaterial({ color: 0xa9754f, roughness: 0.8 });
  const shirt = new THREE.MeshStandardMaterial({ color: 0x2b3550, roughness: 0.7 });
  const pants = new THREE.MeshStandardMaterial({ color: 0x1c1712, roughness: 0.8 });
  const hairMat = new THREE.MeshStandardMaterial({ color: 0x140f0b, roughness: 0.6 });
  const bagMat = new THREE.MeshStandardMaterial({ color: 0xded2b8, roughness: 0.9 });

  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.85, 0.36), shirt);
  torso.position.y = 1.05;
  group.add(torso);

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 12, 12), skin);
  head.position.y = 1.68;
  group.add(head);

  const hair = new THREE.Mesh(new THREE.SphereGeometry(0.225, 12, 12, 0, Math.PI * 2, 0, Math.PI * 0.55), hairMat);
  hair.position.y = 1.72;
  group.add(hair);

  const bag = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.34, 0.16), bagMat);
  bag.position.set(0.18, 0.7, 0.24);
  group.add(bag);
  const strap = new THREE.Mesh(new THREE.BoxGeometry(0.08, 1.0, 0.08), bagMat);
  strap.position.set(-0.05, 1.15, 0.2);
  strap.rotation.z = 0.5;
  group.add(strap);

  function limb(mat, length) {
    const g = new THREE.Group();
    const mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.06, length, 8), mat);
    mesh.position.y = -length / 2;
    g.add(mesh);
    return g;
  }
  const armL = limb(shirt, 0.62); armL.position.set(-0.32, 1.42, 0);
  const armR = limb(shirt, 0.62); armR.position.set(0.32, 1.42, 0);
  const legL = limb(pants, 0.78); legL.position.set(-0.16, 0.78, 0);
  const legR = limb(pants, 0.78); legR.position.set(0.16, 0.78, 0);
  group.add(armL, armR, legL, legR);

  return { group, torso, head, armL, armR, legL, legR };
}

const playerParts = buildPlayer();
scene.add(playerParts.group);
const playerShadow = shadowBlob(0.4);

const player = {
  laneIndex: 1,
  x: LANES[1],
  targetLaneIndex: 1,
  jumping: false,
  jumpT: 0,
  ducking: false,
  duckT: 0,
  legPhase: 0,
  z: 0,
};

// ---------- roach ----------
function buildRoach() {
  const group = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color: 0x3f2a1e, roughness: 0.35, metalness: 0.15 });
  const darkMat = new THREE.MeshStandardMaterial({ color: 0x1c130c, roughness: 0.5 });

  const body = new THREE.Mesh(new THREE.SphereGeometry(0.5, 14, 10), bodyMat);
  body.scale.set(1, 0.55, 1.5);
  body.position.y = 0.32;
  group.add(body);

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 10, 8), darkMat);
  head.position.set(0, 0.34, 0.62);
  group.add(head);

  const legs = [];
  for (let i = -1; i <= 1; i++) {
    for (const side of [-1, 1]) {
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.02, 0.55, 6), darkMat);
      leg.position.set(side * 0.45, 0.24, i * 0.25);
      leg.rotation.z = side * 0.9;
      group.add(leg);
      legs.push({ mesh: leg, phase: i + side });
    }
  }

  for (const side of [-1, 1]) {
    const ant = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.03, 0.55, 6), darkMat);
    ant.position.set(side * 0.12, 0.62, 0.95);
    ant.rotation.x = -0.9;
    ant.rotation.z = side * 0.3;
    group.add(ant);
  }

  return { group, legs, body };
}

const roachParts = buildRoach();
scene.add(roachParts.group);
const roachShadow = shadowBlob(0.6);

// ---------- input ----------
let state = "idle";
function trySwitchLane(dir) {
  player.targetLaneIndex = clamp(player.targetLaneIndex + dir, 0, 2);
}
function tryJump() {
  if (!player.jumping && !player.ducking) {
    player.jumping = true;
    player.jumpT = 0;
  }
}
function setDuck(on) {
  if (!player.jumping) player.ducking = on;
}

window.addEventListener("keydown", (e) => {
  if (state !== "running") return;
  if (e.key === "ArrowLeft" || e.key === "a") trySwitchLane(-1);
  if (e.key === "ArrowRight" || e.key === "d") trySwitchLane(1);
  if (e.key === "ArrowUp" || e.key === " " || e.key === "w") tryJump();
  if (e.key === "ArrowDown" || e.key === "s") setDuck(true);
});
window.addEventListener("keyup", (e) => {
  if (e.key === "ArrowDown" || e.key === "s") setDuck(false);
});

let touchStart = null;
renderer.domElement.addEventListener("touchstart", (e) => {
  const t = e.changedTouches[0];
  touchStart = { x: t.clientX, y: t.clientY };
}, { passive: true });
renderer.domElement.addEventListener("touchend", (e) => {
  if (!touchStart || state !== "running") return;
  const t = e.changedTouches[0];
  const dx = t.clientX - touchStart.x;
  const dy = t.clientY - touchStart.y;
  const adx = Math.abs(dx), ady = Math.abs(dy);
  if (Math.max(adx, ady) < 24) { touchStart = null; return; }
  if (adx > ady) trySwitchLane(dx > 0 ? 1 : -1);
  else if (dy < 0) tryJump();
  else { setDuck(true); setTimeout(() => setDuck(false), 350); }
  touchStart = null;
}, { passive: true });

// ---------- backend connection ----------
async function loadHighScore() {
  try {
    const res = await fetch("/api/highscore");
    const data = await res.json();
    bestEl.textContent = data.highScore || 0;
  } catch (e) {
    bestEl.textContent = localStorage.getItem("roach_best") || 0;
  }
}
async function submitScore(finalScore) {
  let beat = false;
  try {
    const res = await fetch("/api/highscore", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ score: finalScore }),
    });
    const data = await res.json();
    bestEl.textContent = data.highScore;
    beat = data.updated;
  } catch (e) {
    const prev = Number(localStorage.getItem("roach_best") || 0);
    if (finalScore > prev) {
      localStorage.setItem("roach_best", finalScore);
      bestEl.textContent = finalScore;
      beat = true;
    }
  }
  return beat;
}

// ---------- obstacles ----------
const SPAWN_Z = -70;
const DESPAWN_Z = 2;
const TYPES = ["ground", "overhead", "block"];
let obstacles = [];

function makeObstacleMesh(type) {
  if (type === "ground") {
    const g = new THREE.Group();
    const base = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.18, 0.5), new THREE.MeshStandardMaterial({ color: 0x8a5a34 }));
    base.position.y = 0.09;
    const spring = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.4, 0.12), new THREE.MeshStandardMaterial({ color: 0xc1443c }));
    spring.position.y = 0.4;
    g.add(base, spring);
    g.userData.type = "ground";
    g.userData.height = 0.5;
    return g;
  }
  if (type === "overhead") {
    const g = new THREE.Group();
    const bar = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.1, 0.1), new THREE.MeshStandardMaterial({ color: 0x4a4038 }));
    bar.position.y = 2.1;
    g.add(bar);
    for (let i = -0.6; i <= 0.6; i += 0.4) {
      const strand = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.55, 6), new THREE.MeshStandardMaterial({ color: 0xdcdcd2, transparent: true, opacity: 0.6 }));
      strand.position.set(i, 1.75, 0);
      strand.rotation.x = Math.PI;
      g.add(strand);
    }
    g.userData.type = "overhead";
    g.userData.lowY = 1.55;
    return g;
  }
  const g = new THREE.Group();
  const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 1.7, 8), new THREE.MeshStandardMaterial({ color: 0xcaa26b }));
  handle.position.y = 1.5;
  const bristle = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.22, 0.55, 10), new THREE.MeshStandardMaterial({ color: 0xd9c48f }));
  bristle.position.y = 0.4;
  g.add(handle, bristle);
  g.userData.type = "block";
  return g;
}

function spawnObstacle() {
  const laneIndex = Math.floor(Math.random() * 3);
  const type = TYPES[Math.floor(Math.random() * TYPES.length)];
  const mesh = makeObstacleMesh(type);
  mesh.position.set(LANES[laneIndex], 0, SPAWN_Z);
  scene.add(mesh);
  obstacles.push({ mesh, laneIndex, type, cleared: false });
}

// ---------- game state ----------
let elapsed = 0;
let speed = 9;
const BASE_SPEED = 9;
const MAX_SPEED = 24;
let score = 0;
let spawnTimer = 0.8;
let chaseGap = 6.5;
const MIN_GAP = 1.0;
const MAX_GAP = 6.5;
let pounceT = 0;

function resetGame() {
  state = "running";
  elapsed = 0;
  speed = BASE_SPEED;
  score = 0;
  chaseGap = MAX_GAP;
  pounceT = 0;
  spawnTimer = 0.8;
  player.laneIndex = 1;
  player.targetLaneIndex = 1;
  player.jumping = false;
  player.ducking = false;
  player.jumpT = 0;
  for (const o of obstacles) scene.remove(o.mesh);
  obstacles = [];
  scoreEl.textContent = "0";
}

function triggerCaught() {
  state = "caught";
  pounceT = 0;
}

function gameOver() {
  state = "dead";
  const finalScore = Math.floor(score);
  finalScoreEl.textContent = finalScore;
  submitScore(finalScore).then((beat) => newBestEl.classList.toggle("hidden", !beat));
  gameOverScreen.classList.remove("hidden");
}

startBtn.addEventListener("click", () => { startScreen.classList.add("hidden"); resetGame(); });
retryBtn.addEventListener("click", () => { gameOverScreen.classList.add("hidden"); resetGame(); });

// ---------- update ----------
function update(dt) {
  elapsed += dt;
  speed = Math.min(MAX_SPEED, BASE_SPEED + elapsed * 0.22);
  score += dt * (14 + speed * 2.2);
  scoreEl.textContent = Math.floor(score);

  player.x = lerp(player.x, LANES[player.targetLaneIndex], Math.min(1, dt * 9));
  player.laneIndex = player.targetLaneIndex;

  if (player.jumping) {
    player.jumpT += dt * 1.6;
    if (player.jumpT >= 1) { player.jumpT = 0; player.jumping = false; }
  }
  player.duckT = lerp(player.duckT, player.ducking ? 1 : 0, Math.min(1, dt * 12));
  player.legPhase += dt * (7 + speed * 0.45);

  const targetGap = clamp(MAX_GAP - elapsed * 0.11, MIN_GAP + 0.4, MAX_GAP);
  chaseGap = lerp(chaseGap, targetGap, dt * 0.6);
  gapFillEl.style.width = `${clamp(((chaseGap - MIN_GAP) / (MAX_GAP - MIN_GAP)) * 100, 4, 100)}%`;

  spawnTimer -= dt;
  const spawnEvery = clamp(1.05 - speed * 0.022, 0.42, 1.05);
  if (spawnTimer <= 0) { spawnObstacle(); spawnTimer = spawnEvery; }

  for (const o of obstacles) {
    o.mesh.position.z += speed * dt;
    if (!o.cleared && o.mesh.position.z > -0.6 && o.mesh.position.z < 0.6) {
      if (o.laneIndex === player.laneIndex) {
        let avoided = false;
        if (o.type === "ground" && player.jumping && player.jumpT > 0.15 && player.jumpT < 0.85) avoided = true;
        if (o.type === "overhead" && player.duckT > 0.5) avoided = true;
        if (!avoided) { triggerCaught(); return; }
      }
      o.cleared = true;
    }
  }
  obstacles = obstacles.filter((o) => {
    if (o.mesh.position.z > DESPAWN_Z + 3) { scene.remove(o.mesh); return false; }
    return true;
  });

  for (const lamp of lamps) {
    lamp.position.z += speed * dt;
    if (lamp.position.z > 6) lamp.position.z -= 120;
  }
}

// ---------- render/pose ----------
function poseHuman() {
  const g = playerParts.group;
  const jumpH = player.jumping ? Math.sin(player.jumpT * Math.PI) * 1.5 : 0;
  const duckScale = lerp(1, 0.68, player.duckT);
  g.position.set(player.x, jumpH, 0);
  g.scale.y = duckScale;

  const legSwing = player.jumping ? 0.5 : Math.sin(player.legPhase) * 0.55;
  playerParts.legL.rotation.x = legSwing;
  playerParts.legR.rotation.x = -legSwing;
  playerParts.armL.rotation.x = -legSwing;
  playerParts.armR.rotation.x = legSwing;

  playerShadow.position.set(player.x, 0.02, 0);
  playerShadow.material.opacity = clamp(0.4 - jumpH * 0.22, 0.08, 0.4);
  const sc = lerp(1, 0.55, jumpH / 1.5);
  playerShadow.scale.set(sc, sc, sc);
}

function poseRoach() {
  let z = 0 + chaseGap;
  const closeness = 1 - clamp((chaseGap - MIN_GAP) / (MAX_GAP - MIN_GAP), 0, 1);
  if (state === "caught") {
    pounceT = Math.min(1, pounceT + 0.045);
    z = lerp(chaseGap, -0.3, pounceT);
    if (pounceT >= 1 && gameOverScreen.classList.contains("hidden")) gameOver();
  }
  const roachX = lerp(player.x, 0, 0.3);
  roachParts.group.position.set(roachX, 0, z);
  const scale = lerp(0.85, 1.35, closeness);
  roachParts.group.scale.set(scale, scale, scale);

  for (const leg of roachParts.legs) {
    leg.mesh.rotation.x = Math.sin(elapsed * 22 + leg.phase) * 0.35;
  }
  roachShadow.position.set(roachX, 0.015, z);
  roachShadow.scale.set(scale, scale, scale);

  const dangerT = closeness;
  scene.fog.color.setHex(dangerT > 0.75 ? 0x2a0f0c : FOG_COLOR);
}

function updateCamera() {
  const camTargetX = lerp(camera.position.x, player.x * 0.5, 0.08);
  camera.position.x = camTargetX;
  camera.position.y = 3.4 + Math.sin(player.legPhase * 2) * 0.02;
  camera.lookAt(player.x * 0.6, 1.1, -9);
  bulb.position.x = player.x * 0.4;
}

// ---------- loop ----------
let lastTime = performance.now();
function loop(now) {
  const dt = Math.min(0.05, (now - lastTime) / 1000);
  lastTime = now;

  if (state === "running") update(dt);
  poseHuman();
  poseRoach();
  updateCamera();

  renderer.render(scene, camera);
  requestAnimationFrame(loop);
}

loadHighScore();
requestAnimationFrame(loop);
